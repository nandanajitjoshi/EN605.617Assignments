The assignment.exe file is already shared in the folder
To run the file on windows, use .\assignment8 [Problem Size] 

To compile file for any other operating environment, use the command - 
nvcc Assignment8.cu -o assignment8